from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os

def lambda_handler(event, context):
    for record in event['Records']:
        response = ""
        try:
            print ("test")
            payload=record["body"]
            print(str(payload))
            # TODO implement
            print("Starting Scrapping")
            chrome_options = Options()
            response = "BLANC RESPONSE1"
            chrome_options.add_argument('--headless')
            response = "BLANC RESPONSE2"
            chrome_options.add_argument('--no-sandbox')
            response = "BLANC RESPONSE3"
            chrome_options.add_argument('--disable-gpu')
            response = "BLANC RESPONSE4"
            chrome_options.add_argument('--window-size=1280x1696')
            response = "BLANC RESPONSE5"
            chrome_options.add_argument('--user-data-dir=/tmp/user-data')
            response = "BLANC RESPONSE6"
            chrome_options.add_argument('--hide-scrollbars')
            response = "BLANC RESPONSE7"
            chrome_options.add_argument('--enable-logging')
            response = "BLANC RESPONSE8"
            chrome_options.add_argument('--log-level=0')
            response = "BLANC RESPONSE9"
            chrome_options.add_argument('--v=99')
            response = "BLANC RESPONSE10"
            chrome_options.add_argument('--single-process')
            response = "BLANC RESPONSE11"
            chrome_options.add_argument('--data-path=/tmp/data-path')
            response = "BLANC RESPONSE12"
            chrome_options.add_argument('--ignore-certificate-errors')
            response = "BLANC RESPONSE13"
            chrome_options.add_argument('--homedir=/tmp')
            response = "BLANC RESPONSE14"
            chrome_options.add_argument('--disk-cache-dir=/tmp/cache-dir')
            response = "BLANC RESPONSE15"
            chrome_options.add_argument('user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36')
            response = "BLANC RESPONSE16"
            chrome_options.binary_location = os.getcwd() + "/bin/headless-chromium"
            response = "BLANC RESPONSE17"
            driver = webdriver.Chrome(chrome_options=chrome_options)
            driver.get('https://www.neaminational.org.au/')
            response = driver.page_source
            driver.close()
        except Exception as e:
            print(str(e))
            print("EXCEPTION OCCURED!")
        print(response)
